/*
 * Typed wrapper around the Kotlin @JavascriptInterface `AndroidBridge`.
 *
 * SSOT: devices/android/app/src/main/java/dev/ponomarev/executor/webview/AndroidBridge.kt
 * Causality: #for-bridge-secret-write-only, #for-bridge-async-ticket-poll, #for-bundle-webview-as-launcher,
 *   #for-bundle-night-mode-pref, #for-bundle-systembars-from-js
 *
 * The bundle must never assume presence of a bridge method without this wrapper — keeps the coupling
 * surface in one place and makes it easy to audit the full bridge footprint.
 */
(function (global) {
  'use strict';

  var native = global.AndroidBridge;

  function assertBridge() {
    if (!native) {
      throw new Error('AndroidBridge not injected — running outside the WebView host');
    }
  }

  function toBool(v) {
    return v === true || v === 'true';
  }

  /**
   * Normalize any CSS color string (rgb/rgba/hex/named) to `#RRGGBB` for Kotlin parsing.
   * Alpha is discarded — the system bars are opaque tokens, alpha blending against window
   * content is handled by Android itself.
   */
  function normalizeHex(color) {
    var s = String(color || '').trim();
    if (!s) return '#000000';
    if (s.charAt(0) === '#') {
      if (s.length === 4) {
        return '#' + s.charAt(1) + s.charAt(1) + s.charAt(2) + s.charAt(2) + s.charAt(3) + s.charAt(3);
      }
      if (s.length === 9) return '#' + s.slice(1, 7);
      return s;
    }
    var m = s.match(/^rgba?\(\s*(\d+)[\s,]+(\d+)[\s,]+(\d+)/);
    if (m) {
      var hex = '#';
      for (var i = 1; i <= 3; i++) {
        var h = (parseInt(m[i], 10) | 0).toString(16);
        hex += h.length < 2 ? '0' + h : h;
      }
      return hex;
    }
    return '#000000';
  }

  var api = {
    // -------- Shell / device --------
    getShellVersion: function () {
      assertBridge();
      return String(native.getShellVersion() || '');
    },
    getDeviceId: function () {
      assertBridge();
      return String(native.getDeviceId() || '');
    },
    getAppDeviceId: function () {
      assertBridge();
      return String(native.getAppDeviceId() || '');
    },
    copyToClipboard: function (text, label) {
      assertBridge();
      native.copyToClipboard(String(text || ''), String(label || 'text'));
    },
    toast: function (text) {
      assertBridge();
      native.toast(String(text || ''));
    },
    logToLogcat: function (level, tag, msg) {
      assertBridge();
      native.logToLogcat(String(level), String(tag), String(msg));
    },
    /**
     * Paint Android status-bar and navigation-bar using bundle chrome tokens.
     * Arguments accept CSS color strings; they are normalized to `#RRGGBB` before being
     * passed to Kotlin (the bridge side uses `android.graphics.Color.parseColor`).
     * No-op if the bridge method is absent (older shell APK — graceful downgrade).
     */
    setSystemBarColors: function (statusColor, navigationColor) {
      assertBridge();
      if (typeof native.setSystemBarColors !== 'function') return;
      native.setSystemBarColors(normalizeHex(statusColor), normalizeHex(navigationColor));
    },
    /** Stored AppCompat night mode: `light` | `dark` | `follow_system` (legacy; bundle cycles light↔dark only). */
    getNightModePreference: function () {
      assertBridge();
      if (typeof native.getNightModePreference !== 'function') return 'follow_system';
      return String(native.getNightModePreference() || 'follow_system');
    },
    setNightModePreference: function (mode) {
      assertBridge();
      if (typeof native.setNightModePreference !== 'function') return { ok: false };
      try {
        return JSON.parse(String(native.setNightModePreference(String(mode || ''))));
      } catch (_e) {
        return { ok: false };
      }
    },

    // -------- Auth / session --------
    isAuthenticated: function () {
      assertBridge();
      return toBool(native.isAuthenticated());
    },
    getJwt: function () {
      assertBridge();
      return String(native.getJwt() || '');
    },
    getWorkerBaseUrl: function () {
      assertBridge();
      if (typeof native.getWorkerBaseUrl !== 'function') return '';
      return String(native.getWorkerBaseUrl() || '');
    },
    getAppApiBaseUrl: function () {
      assertBridge();
      if (typeof native.getAppApiBaseUrl !== 'function') return '';
      return String(native.getAppApiBaseUrl() || '');
    },
    clearSession: function () {
      assertBridge();
      native.clearSession();
    },

    /**
     * Async login flow — returns a Promise that resolves to:
     *   { status: 'ok' } | { status: 'err', reason: 'jwt_required' | 'both_keys_required' | 'keys_required' | 'auth_failed' | 'unknown_ticket' }
     */
    login: function (jwt, apiKey, apiSecret) {
      assertBridge();
      var ticket = String(native.beginLogin(String(jwt || ''), String(apiKey || ''), String(apiSecret || '')));
      return new Promise(function (resolve) {
        var tries = 0;
        var timer = setInterval(function () {
          tries += 1;
          var raw;
          try {
            raw = String(native.pollLogin(ticket));
          } catch (e) {
            clearInterval(timer);
            resolve({ status: 'err', reason: 'bridge_error' });
            return;
          }
          var parsed;
          try { parsed = JSON.parse(raw); } catch (_e) { parsed = { status: 'err', reason: 'bad_json' }; }
          if (parsed && parsed.status && parsed.status !== 'pending') {
            clearInterval(timer);
            resolve(parsed);
            return;
          }
          // @causality #for-bridge-async-ticket-poll — allowed tries <= 200 (~60 s at 300 ms step); heartbeat timeout is well below.
          if (tries > 200) {
            clearInterval(timer);
            resolve({ status: 'err', reason: 'timeout' });
          }
        }, 300);
      });
    },

    // -------- Bybit credentials (write-only) --------
    hasBybitCredentials: function () {
      assertBridge();
      return toBool(native.hasBybitCredentials());
    },
    setBybitCredentials: function (apiKey, apiSecret) {
      assertBridge();
      native.setBybitCredentials(String(apiKey || ''), String(apiSecret || ''));
    },
    clearBybitCredentials: function () {
      assertBridge();
      native.clearBybitCredentials();
    },

    // -------- Settings --------
    getPollingIntervalSec: function () {
      assertBridge();
      return Number(native.getPollingIntervalSec()) | 0;
    },
    setPollingIntervalSec: function (sec) {
      assertBridge();
      native.setPollingIntervalSec(sec | 0);
    },
    getMaxLogCyclesDisplay: function () {
      assertBridge();
      return Number(native.getMaxLogCyclesDisplay()) | 0;
    },
    setMaxLogCyclesDisplay: function (n) {
      assertBridge();
      native.setMaxLogCyclesDisplay(n | 0);
    },
    getPollingIntervalBounds: function () {
      assertBridge();
      try {
        return JSON.parse(String(native.getPollingIntervalBounds()));
      } catch (_e) {
        return { min: 30, max: 3600 };
      }
    },
    getBundleUpdateStatus: function () {
      assertBridge();
      if (typeof native.getBundleUpdateStatus !== 'function') {
        return { checkedAtMs: 0, status: null, error: null };
      }
      try {
        return JSON.parse(String(native.getBundleUpdateStatus()));
      } catch (_e) {
        return { checkedAtMs: 0, status: 'parse_error', error: 'bad update status payload' };
      }
    },
    requestBundleUpdateCheck: function () {
      assertBridge();
      if (typeof native.requestBundleUpdateCheck !== 'function') {
        return { checkedAtMs: 0, status: 'unsupported', error: 'update request not supported by shell' };
      }
      try {
        return JSON.parse(String(native.requestBundleUpdateCheck()));
      } catch (_e) {
        return { checkedAtMs: 0, status: 'parse_error', error: 'bad update request payload' };
      }
    },
    getShellCapabilities: function () {
      assertBridge();
      if (typeof native.getShellCapabilities !== 'function') {
        return { bundleUpdateStatus: false, bundleUpdateRequest: false };
      }
      try {
        return JSON.parse(String(native.getShellCapabilities()));
      } catch (_e) {
        return { bundleUpdateStatus: false, bundleUpdateRequest: false };
      }
    },

    // -------- Foreground service --------
    startExecutorService: function () {
      assertBridge();
      native.startExecutorService();
    },
    stopExecutorService: function () {
      assertBridge();
      native.stopExecutorService();
    },
    forceCycle: function () {
      assertBridge();
      native.forceCycle();
    },
    isExecutorServiceRunning: function () {
      assertBridge();
      return toBool(native.isExecutorServiceRunning());
    },

    // -------- Event log --------
    getEventLogSnapshot: function () {
      assertBridge();
      return String(native.getEventLogSnapshot() || '');
    },
    getRuntimeLogEmptyLabel: function () {
      assertBridge();
      return String(native.getRuntimeLogEmptyLabel() || '');
    },
    clearEventLog: function () {
      assertBridge();
      native.clearEventLog();
    },

    // -------- Bybit signing (non-credential usage) --------
    signBybit: function (apiSecret, prehashString) {
      assertBridge();
      return String(native.signBybit(String(apiSecret || ''), String(prehashString || '')));
    },
    base64Encode: function (utf8) {
      assertBridge();
      return String(native.base64Encode(String(utf8 || '')));
    },
  };

  global.MmbBridge = api;
})(window);
