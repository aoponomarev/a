/*
 * Main UI logic — mirrors ExecutorMainScreen.kt behaviour piece-by-piece over window.MmbBridge.
 * SSOT: id:ais-5e1d39. UI chrome is EN-only (#for-bundle-chrome-en-only); log lines stay localized.
 */
(function () {
  'use strict';

  var bridge = window.MmbBridge;

  // ---------- DOM refs ----------
  var $ = function (id) { return document.getElementById(id); };

  var topbar = $('topbar');
  var screenLogin = $('screen-login');
  var screenDash  = $('screen-dashboard');

  var loginPanel     = $('login-panel');
  var jwtField       = $('login-jwt');
  var keyField       = $('login-key');
  var secretField    = $('login-secret');
  var connectBtn     = $('btn-connect');
  var jwtErrorBox    = $('login-jwt-error');

  var intervalLabel  = $('interval-label');
  var logView        = $('log-view');
  var runBtn         = $('btn-run');
  var stopBtn        = $('btn-stop');
  var clearBtn       = $('btn-clear');
  var logoutBtn      = $('btn-logout');
  var gearBtn        = $('btn-settings');
  var themeBtn       = $('btn-theme');
  var credsBtn       = $('btn-creds');

  /** Cycle order for AppCompat night mode (#for-bundle-night-mode-pref). */
  var THEME_ORDER = ['follow_system', 'light', 'dark'];

  // Dialogs
  var dlgDevice      = $('dlg-device');
  var dlgCreds       = $('dlg-creds');
  var dlgInterval    = $('dlg-interval');
  var dlgSettings    = $('dlg-settings');

  // ---------- State ----------
  var state = {
    runStopSelection: null,   // null = neither, true = Run, false = Stop
    clearHighlight: false,    // Clear button green until new log lines appear
    logSettingsBump: 0,
    pollTimer: null,
  };

  // ---------- Helpers ----------
  function showScreen(name) {
    screenLogin.dataset.active = (name === 'login') ? 'true' : 'false';
    screenDash.dataset.active  = (name === 'dashboard') ? 'true' : 'false';
    /* Top bar always visible (gear, theme, logo, creds on login + dashboard). */
    topbar.hidden = false;
    /* Hide small header logo only on login (CSS); dashboard keeps it. */
    if (name === 'login') {
      document.body.classList.add('screen-login-active');
    } else {
      document.body.classList.remove('screen-login-active');
    }
  }

  function updateHasValue(el) {
    el.dataset.hasValue = (el.value && el.value.length > 0) ? 'true' : 'false';
  }

  function bindFieldLabelState(el) {
    updateHasValue(el);
    el.addEventListener('input', function () { updateHasValue(el); });
  }

  function setFieldError(inputEl, errEl, message) {
    if (message) {
      inputEl.dataset.error = 'true';
      errEl.textContent = message;
      errEl.hidden = false;
    } else {
      inputEl.dataset.error = 'false';
      errEl.textContent = '';
      errEl.hidden = true;
    }
  }

  function updateCredsIcon() {
    var has = bridge.hasBybitCredentials();
    credsBtn.dataset.inactive = has ? 'false' : 'true';
    credsBtn.dataset.activeKeys = has ? 'true' : 'false';
  }

  function updateConnectEnabled() {
    var jwt = jwtField.value.trim();
    var key = keyField.value.trim();
    var sec = secretField.value.trim();
    var canConnect = true;
    if (!jwt) canConnect = false;
    if ((key && !sec) || (!key && sec)) canConnect = false;
    if (!key && !bridge.hasBybitCredentials()) canConnect = false;
    connectBtn.disabled = !canConnect;
  }

  function refreshIntervalLabel() {
    var sec = bridge.getPollingIntervalSec();
    intervalLabel.textContent = 'Interval ' + sec + ' s';
  }

  function stylizeRunStopButton() {
    // run
    runBtn.classList.remove('btn-primary', 'btn-outlined');
    runBtn.classList.add(state.runStopSelection === true ? 'btn-primary' : 'btn-outlined');
    // stop
    stopBtn.classList.remove('btn-danger', 'btn-outlined');
    stopBtn.classList.add(state.runStopSelection === false ? 'btn-danger' : 'btn-outlined');
    // clear
    clearBtn.classList.remove('btn-primary', 'btn-outlined');
    clearBtn.classList.add(state.clearHighlight ? 'btn-primary' : 'btn-outlined');
  }

  function refreshLog() {
    var txt = bridge.getEventLogSnapshot();
    if (!txt) {
      logView.textContent = bridge.getRuntimeLogEmptyLabel();
      return;
    }
    var hadContent = logView.dataset.hasContent === 'true';
    logView.textContent = txt;
    logView.dataset.hasContent = 'true';
    if (!hadContent || state.clearHighlight) {
      state.clearHighlight = false;
      stylizeRunStopButton();
    }
    logView.scrollTop = 0;
  }

  function startPolling() {
    if (state.pollTimer) return;
    state.pollTimer = setInterval(function () {
      try {
        refreshLog();
      } catch (e) {
        bridge.logToLogcat('ERROR', 'MmbBundle', 'poll error: ' + (e && e.message));
      }
    }, 2000);
  }

  function stopPolling() {
    if (state.pollTimer) { clearInterval(state.pollTimer); state.pollTimer = null; }
  }

  function enterDashboard() {
    showScreen('dashboard');
    updateCredsIcon();
    refreshIntervalLabel();
    refreshLog();
    bridge.startExecutorService();
    startPolling();
  }

  function enterLogin() {
    stopPolling();
    showScreen('login');
    jwtField.value = bridge.getJwt();
    keyField.value = '';
    secretField.value = '';
    [jwtField, keyField, secretField].forEach(updateHasValue);
    setFieldError(jwtField, jwtErrorBox, null);
    updateConnectEnabled();
  }

  // ---------- Login flow ----------
  function doConnect() {
    var jwt = jwtField.value.trim();
    var key = keyField.value.trim();
    var sec = secretField.value.trim();
    setFieldError(jwtField, jwtErrorBox, null);
    connectBtn.disabled = true;
    bridge.login(jwt, key, sec).then(function (res) {
      if (res.status === 'ok') {
        enterDashboard();
      } else {
        var reason = res.reason || 'auth_failed';
        var messages = {
          jwt_required: 'JWT token required',
          both_keys_required: 'Fill both API key and API secret',
          keys_required: 'Bybit API key and secret required',
          auth_failed: 'Authentication failed',
          timeout: 'Authentication timeout',
          bridge_error: 'Bridge error',
          unknown_ticket: 'Internal error',
        };
        setFieldError(jwtField, jwtErrorBox, messages[reason] || reason);
        updateConnectEnabled();
      }
    });
  }

  // ---------- Dialog wiring ----------
  function wireDialogCloseButtons() {
    document.querySelectorAll('[data-close]').forEach(function (el) {
      el.addEventListener('click', function () {
        var id = el.getAttribute('data-close');
        var dlg = $(id);
        if (dlg && dlg.open) dlg.close();
      });
    });
  }

  function openDeviceDialog() {
    $('dlg-device-id').textContent = bridge.getAppDeviceId();
    dlgDevice.showModal();
  }
  function wireDeviceDialog() {
    $('dlg-device-copy').addEventListener('click', function () {
      var id = bridge.getAppDeviceId();
      bridge.copyToClipboard(id, 'device');
      bridge.toast('Copied');
    });
  }

  function openCredsDialog() {
    // write-only contract — we never preload existing values here (#for-bridge-secret-write-only)
    $('creds-key').value = '';
    $('creds-secret').value = '';
    [$('creds-key'), $('creds-secret')].forEach(updateHasValue);
    dlgCreds.showModal();
  }
  function wireCredsDialog() {
    $('dlg-creds-save').addEventListener('click', function () {
      var k = $('creds-key').value.trim();
      var s = $('creds-secret').value.trim();
      if (k && s) {
        bridge.setBybitCredentials(k, s);
        updateCredsIcon();
      }
      dlgCreds.close();
    });
    $('dlg-creds-clear').addEventListener('click', function () {
      bridge.clearBybitCredentials();
      updateCredsIcon();
      dlgCreds.close();
    });
    [$('creds-key'), $('creds-secret')].forEach(bindFieldLabelState);
  }

  function openIntervalDialog() {
    $('interval-value').value = String(bridge.getPollingIntervalSec());
    var cycles = bridge.getMaxLogCyclesDisplay();
    $('interval-cycles').value = cycles > 0 ? String(cycles) : '';
    [$('interval-value'), $('interval-cycles')].forEach(updateHasValue);
    setFieldError($('interval-value'), $('interval-value-error'), null);
    setFieldError($('interval-cycles'), $('interval-cycles-error'), null);
    dlgInterval.showModal();
  }
  function wireIntervalDialog() {
    $('dlg-interval-save').addEventListener('click', function () {
      var bounds = bridge.getPollingIntervalBounds();
      var val = parseInt($('interval-value').value, 10);
      if (isNaN(val) || val < bounds.min || val > bounds.max) {
        setFieldError(
          $('interval-value'), $('interval-value-error'),
          'Enter a number between ' + bounds.min + ' and ' + bounds.max,
        );
        return;
      }
      var cyclesRaw = $('interval-cycles').value.trim();
      var cyclesVal;
      if (cyclesRaw.length === 0) {
        cyclesVal = -1;
      } else {
        var n = parseInt(cyclesRaw, 10);
        if (isNaN(n) || n < 1 || n > 9999) {
          setFieldError(
            $('interval-cycles'), $('interval-cycles-error'),
            'Enter a number between 1 and 9999, or leave empty',
          );
          return;
        }
        cyclesVal = n;
      }
      setFieldError($('interval-value'), $('interval-value-error'), null);
      setFieldError($('interval-cycles'), $('interval-cycles-error'), null);
      bridge.setPollingIntervalSec(val);
      bridge.setMaxLogCyclesDisplay(cyclesVal);
      refreshIntervalLabel();
      refreshLog();
      dlgInterval.close();
    });
    [$('interval-value'), $('interval-cycles')].forEach(bindFieldLabelState);
  }

  // ---------- Settings (diagnostic) modal ----------
  function refreshDiagnosticModal() {
    $('diag-shell-version').textContent = bridge.getShellVersion() || '—';
    $('diag-app-device-id').textContent = bridge.getAppDeviceId() || '—';
    $('diag-android-id').textContent = bridge.getDeviceId() || '—';
    $('diag-auth').textContent = bridge.isAuthenticated() ? 'yes' : 'no';
    $('diag-creds').textContent = bridge.hasBybitCredentials() ? 'stored' : 'missing';
    $('diag-service').textContent = bridge.isExecutorServiceRunning() ? 'running' : 'stopped';
  }
  function diagLog(msg) {
    var pre = $('diag-log-view');
    var ts = new Date().toISOString().substr(11, 12);
    pre.textContent = (pre.textContent ? pre.textContent + '\n' : '') + ts + '  ' + msg;
    pre.scrollTop = pre.scrollHeight;
  }
  function wireSettingsDialog() {
    gearBtn.addEventListener('click', function () {
      refreshDiagnosticModal();
      $('diag-log-view').textContent = '';
      diagLog('settings modal opened — bundle ' + '26041713');
      dlgSettings.showModal();
    });
    $('diag-refresh').addEventListener('click', function () {
      refreshDiagnosticModal();
      diagLog('state refreshed');
    });
    $('diag-logcat').addEventListener('click', function () {
      bridge.logToLogcat('INFO', 'MmbBundle', 'ping from bundle 26041713');
      diagLog('logcat ping sent as INFO MmbBundle');
    });
    $('diag-sign').addEventListener('click', function () {
      try {
        var hex = bridge.signBybit('test-secret', 'probe-payload');
        diagLog('HMAC ok: ' + hex.substr(0, 16) + '…');
      } catch (e) {
        diagLog('HMAC fail: ' + (e && e.message));
      }
    });
    $('diag-force-cycle').addEventListener('click', function () {
      bridge.forceCycle();
      diagLog('force cycle requested');
    });
  }

  // ---------- Dashboard wiring ----------
  function wireDashboard() {
    runBtn.addEventListener('click', function () {
      state.runStopSelection = true;
      state.clearHighlight = false;
      stylizeRunStopButton();
      bridge.forceCycle();
    });
    stopBtn.addEventListener('click', function () {
      state.runStopSelection = false;
      state.clearHighlight = false;
      stylizeRunStopButton();
      bridge.stopExecutorService();
    });
    clearBtn.addEventListener('click', function () {
      bridge.clearEventLog();
      state.clearHighlight = true;
      stylizeRunStopButton();
      refreshLog();
    });
    logoutBtn.addEventListener('click', function () {
      bridge.clearSession();
      enterLogin();
    });
    intervalLabel.addEventListener('click', openIntervalDialog);
    credsBtn.addEventListener('click', openCredsDialog);
    gearBtn.addEventListener('click', function () { /* handled via wireSettingsDialog */ });
  }

  function wireTopbarDeviceViaLongPress() {
    // @causality #for-gear-long-press-device-id — gear short-press opens settings modal (diagnostic);
    // long-press (>=500ms) opens the Device ID dialog, matching ExecutorTopBar's device-id slot.
    var pressTimer = null;
    var longFired = false;
    gearBtn.addEventListener('touchstart', function () {
      longFired = false;
      pressTimer = setTimeout(function () {
        longFired = true;
        openDeviceDialog();
      }, 500);
    });
    var cancel = function () { if (pressTimer) { clearTimeout(pressTimer); pressTimer = null; } };
    gearBtn.addEventListener('touchend', cancel);
    gearBtn.addEventListener('touchcancel', cancel);
    gearBtn.addEventListener('touchmove', cancel);
    gearBtn.addEventListener('click', function (e) {
      if (longFired) { e.stopImmediatePropagation(); e.preventDefault(); longFired = false; }
    }, true);
  }

  // ---------- Login wiring ----------
  function wireLogin() {
    [jwtField, keyField, secretField].forEach(bindFieldLabelState);
    [jwtField, keyField, secretField].forEach(function (el) {
      el.addEventListener('input', updateConnectEnabled);
    });
    connectBtn.addEventListener('click', doConnect);
    wireLoginKeyboardFocus();
  }

  /**
   * When any login field is focused, collapse hero logo + footer so the field stack
   * can use vertical space while the soft keyboard is open (WebView/Android).
   * Connect / hint are not form fields — focusing them clears the compact layout.
   */
  function wireLoginKeyboardFocus() {
    if (!loginPanel) return;
    function isLoginField(el) {
      return el === jwtField || el === keyField || el === secretField;
    }
    loginPanel.addEventListener('focusin', function (e) {
      if (isLoginField(e.target)) loginPanel.classList.add('login--field-focused');
    });
    loginPanel.addEventListener('focusout', function (e) {
      var next = e.relatedTarget;
      if (isLoginField(next)) return;
      loginPanel.classList.remove('login--field-focused');
    });
  }

  /**
   * Resolve light/dark from AppCompat night preference + system (follow_system).
   * `prefers-color-scheme` alone is unreliable in WebView; we drive CSS via
   * `document.documentElement.dataset.theme` instead.
   */
  function resolveEffectiveTheme() {
    var pref = bridge.getNightModePreference();
    if (pref === 'light') return 'light';
    if (pref === 'dark') return 'dark';
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }

  function applyHtmlTheme() {
    var t = resolveEffectiveTheme();
    document.documentElement.setAttribute('data-theme', t);
  }

  // Paint the Android system status-bar + navigation-bar using the same token the bundle
  // uses for its in-page header/footer chrome (`--surface-container`). Re-applied on theme
  // change so the OS chrome follows the bundle palette.
  function applySystemBarColors() {
    var root = getComputedStyle(document.documentElement);
    var token = root.getPropertyValue('--surface-container').trim() || '#252729';
    try {
      bridge.setSystemBarColors(token, token);
    } catch (_e) { /* older shell APK — method absent */ }
  }

  function syncThemeChrome(pref) {
    var p = THEME_ORDER.indexOf(pref) >= 0 ? pref : 'follow_system';
    var label = p === 'light' ? 'Color theme: light'
      : (p === 'dark' ? 'Color theme: dark' : 'Color theme: match device');
    if (themeBtn) {
      themeBtn.dataset.themePref = p;
      themeBtn.setAttribute('aria-label', label);
    }
  }

  function cycleThemePreference() {
    var cur = bridge.getNightModePreference();
    var i = THEME_ORDER.indexOf(cur);
    if (i < 0) i = 0;
    var next = THEME_ORDER[(i + 1) % THEME_ORDER.length];
    var res = bridge.setNightModePreference(next);
    if (!res || !res.ok) {
      try { bridge.toast('Install the latest app to change theme'); } catch (_e) {}
      return;
    }
    /* Activity recreates — DOM is replaced; no need to sync icons here. */
  }

  function wireThemeButtons() {
    if (themeBtn) themeBtn.addEventListener('click', cycleThemePreference);
  }

  // ---------- Boot ----------
  function boot() {
    applyHtmlTheme();
    wireLogin();
    wireDashboard();
    wireDialogCloseButtons();
    wireDeviceDialog();
    wireCredsDialog();
    wireIntervalDialog();
    wireSettingsDialog();
    wireTopbarDeviceViaLongPress();
    wireThemeButtons();

    syncThemeChrome(bridge.getNightModePreference());
    applySystemBarColors();
    if (window.matchMedia) {
      var mq = window.matchMedia('(prefers-color-scheme: dark)');
      var onScheme = function () {
        applyHtmlTheme();
        applySystemBarColors();
      };
      if (typeof mq.addEventListener === 'function') {
        mq.addEventListener('change', onScheme);
      } else if (typeof mq.addListener === 'function') {
        mq.addListener(onScheme);
      }
    }

    if (bridge.isAuthenticated()) {
      enterDashboard();
    } else {
      enterLogin();
    }
    bridge.logToLogcat('INFO', 'MmbBundle', 'bundle 26041713 booted');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
