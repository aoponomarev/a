/*
 * Main UI logic — mirrors ExecutorMainScreen.kt behaviour piece-by-piece over window.MmbBridge.
 * SSOT: id:ais-5e1d39. UI chrome is EN-only (#for-bundle-chrome-en-only); log lines stay localized.
 */
(function () {
  'use strict';

  var bridge = window.MmbBridge;

  // ---------- DOM refs ----------
  var $ = function (id) { return document.getElementById(id); };

  var topbar = $('topbar');
  var screenLogin = $('screen-login');
  var screenDash  = $('screen-dashboard');

  var loginPanel     = $('login-panel');
  var jwtInput       = $('login-jwt');
  var jwtTa          = $('login-jwt-ta');
  var keyField       = $('login-key');
  var secretField    = $('login-secret');
  var connectBtn     = $('btn-connect');
  var jwtErrorBox    = $('login-jwt-error');

  var intervalLabel  = $('interval-label');
  var logView        = $('log-view');
  var runBtn         = $('btn-run');
  var stopBtn        = $('btn-stop');
  var clearBtn       = $('btn-clear');
  var logoutBtn      = $('btn-logout');
  var gearBtn        = $('btn-settings');
  var themeBtn       = $('btn-theme');
  var credsBtn       = $('btn-creds');

  // Dialogs
  var dlgDevice      = $('dlg-device');
  var dlgCreds       = $('dlg-creds');
  var dlgInterval    = $('dlg-interval');
  var dlgSettings    = $('dlg-settings');

  // ---------- State ----------
  var state = {
    runStopSelection: null,   // null = neither, true = Run, false = Stop
    clearHighlight: false,    // Clear button green until new log lines appear
    logSettingsBump: 0,
    pollTimer: null,
  };

  // ---------- Helpers ----------
  function showScreen(name) {
    screenLogin.dataset.active = (name === 'login') ? 'true' : 'false';
    screenDash.dataset.active  = (name === 'dashboard') ? 'true' : 'false';
    /* Top bar always visible (gear, theme, logo, creds on login + dashboard). */
    topbar.hidden = false;
    /* Hide small header logo only on login (CSS); dashboard keeps it. */
    if (name === 'login') {
      document.body.classList.add('screen-login-active');
    } else {
      document.body.classList.remove('screen-login-active');
    }
  }

  function updateHasValue(el) {
    el.dataset.hasValue = (el.value && el.value.length > 0) ? 'true' : 'false';
  }

  function bindFieldLabelState(el) {
    updateHasValue(el);
    el.addEventListener('input', function () { updateHasValue(el); });
  }

  function setFieldError(inputEl, errEl, message) {
    if (message) {
      inputEl.dataset.error = 'true';
      errEl.textContent = message;
      errEl.hidden = false;
    } else {
      inputEl.dataset.error = 'false';
      errEl.textContent = '';
      errEl.hidden = true;
    }
  }

  function updateCredsIcon() {
    var has = bridge.hasBybitCredentials();
    credsBtn.dataset.inactive = has ? 'false' : 'true';
    credsBtn.dataset.activeKeys = has ? 'true' : 'false';
  }

  function jwtValue() {
    return jwtTa && !jwtTa.hidden ? jwtTa.value : jwtInput.value;
  }
  function setJwtValue(v) {
    jwtInput.value = v;
    if (jwtTa) jwtTa.value = v;
  }
  function setJwtFieldError(message) {
    if (message) {
      jwtInput.dataset.error = 'true';
      if (jwtTa) jwtTa.dataset.error = 'true';
      jwtErrorBox.textContent = message;
      jwtErrorBox.hidden = false;
    } else {
      jwtInput.dataset.error = 'false';
      if (jwtTa) jwtTa.dataset.error = 'false';
      jwtErrorBox.textContent = '';
      jwtErrorBox.hidden = true;
    }
  }
  function ensureJwtSingleLineMode() {
    if (!jwtTa || jwtTa.hidden) return;
    jwtInput.value = jwtTa.value;
    jwtTa.hidden = true;
    jwtInput.hidden = false;
    updateHasValue(jwtInput);
    updateHasValue(jwtTa);
  }

  function updateConnectEnabled() {
    var jwt = jwtValue().trim();
    var key = keyField.value.trim();
    var sec = secretField.value.trim();
    var canConnect = true;
    if (!jwt) canConnect = false;
    if ((key && !sec) || (!key && sec)) canConnect = false;
    if (!key && !bridge.hasBybitCredentials()) canConnect = false;
    connectBtn.disabled = !canConnect;
  }

  function refreshIntervalLabel() {
    var sec = bridge.getPollingIntervalSec();
    intervalLabel.textContent = 'Interval ' + sec + ' s';
  }

  function stylizeRunStopButton() {
    // run
    runBtn.classList.remove('btn-primary', 'btn-outlined');
    runBtn.classList.add(state.runStopSelection === true ? 'btn-primary' : 'btn-outlined');
    // stop
    stopBtn.classList.remove('btn-danger', 'btn-outlined');
    stopBtn.classList.add(state.runStopSelection === false ? 'btn-danger' : 'btn-outlined');
    // clear
    clearBtn.classList.remove('btn-primary', 'btn-outlined');
    clearBtn.classList.add(state.clearHighlight ? 'btn-primary' : 'btn-outlined');
  }

  function refreshLog() {
    var txt = bridge.getEventLogSnapshot();
    if (!txt) {
      logView.textContent = bridge.getRuntimeLogEmptyLabel();
      return;
    }
    var hadContent = logView.dataset.hasContent === 'true';
    logView.textContent = txt;
    logView.dataset.hasContent = 'true';
    if (!hadContent || state.clearHighlight) {
      state.clearHighlight = false;
      stylizeRunStopButton();
    }
    logView.scrollTop = 0;
  }

  function startPolling() {
    if (state.pollTimer) return;
    state.pollTimer = setInterval(function () {
      try {
        refreshLog();
      } catch (e) {
        bridge.logToLogcat('ERROR', 'MmbBundle', 'poll error: ' + (e && e.message));
      }
    }, 2000);
  }

  function stopPolling() {
    if (state.pollTimer) { clearInterval(state.pollTimer); state.pollTimer = null; }
  }

  function enterDashboard() {
    showScreen('dashboard');
    updateCredsIcon();
    refreshIntervalLabel();
    refreshLog();
    bridge.startExecutorService();
    startPolling();
  }

  function enterLogin() {
    stopPolling();
    showScreen('login');
    setJwtValue(bridge.getJwt());
    keyField.value = '';
    secretField.value = '';
    ensureJwtSingleLineMode();
    [jwtInput, jwtTa, keyField, secretField].forEach(function (el) { if (el) updateHasValue(el); });
    setJwtFieldError(null);
    updateConnectEnabled();
  }

  // ---------- Login flow ----------
  function doConnect() {
    var jwt = jwtValue().trim();
    var key = keyField.value.trim();
    var sec = secretField.value.trim();
    setJwtFieldError(null);
    connectBtn.disabled = true;
    bridge.login(jwt, key, sec).then(function (res) {
      if (res.status === 'ok') {
        enterDashboard();
      } else {
        var reason = res.reason || 'auth_failed';
        var messages = {
          jwt_required: 'JWT token required',
          both_keys_required: 'Fill both API key and API secret',
          keys_required: 'Bybit API key and secret required',
          auth_failed: 'Authentication failed',
          timeout: 'Authentication timeout',
          bridge_error: 'Bridge error',
          unknown_ticket: 'Internal error',
        };
        setJwtFieldError(messages[reason] || reason);
        updateConnectEnabled();
      }
    });
  }

  // ---------- Dialog wiring ----------
  function wireDialogCloseButtons() {
    document.querySelectorAll('[data-close]').forEach(function (el) {
      el.addEventListener('click', function () {
        var id = el.getAttribute('data-close');
        var dlg = $(id);
        if (dlg && dlg.open) dlg.close();
      });
    });
  }

  function pointInsideDialog(dlg, clientX, clientY) {
    var r = dlg.getBoundingClientRect();
    return clientX >= r.left && clientX <= r.right && clientY >= r.top && clientY <= r.bottom;
  }

  /** Transparent ::backdrop — close any open <dialog> when the click is outside the panel. */
  function wireDialogBackdropClose() {
    document.addEventListener(
      'click',
      function (e) {
        var open = document.querySelectorAll('dialog[open]');
        if (!open.length) return;
        for (var i = 0; i < open.length; i++) {
          if (pointInsideDialog(open[i], e.clientX, e.clientY)) return;
        }
        open.forEach(function (dlg) {
          dlg.close();
        });
      },
      true,
    );
  }

  function openDeviceDialog() {
    $('dlg-device-id').textContent = bridge.getAppDeviceId();
    dlgDevice.showModal();
  }
  function wireDeviceDialog() {
    $('dlg-device-copy').addEventListener('click', function () {
      var id = bridge.getAppDeviceId();
      bridge.copyToClipboard(id, 'device');
      bridge.toast('Copied');
    });
  }

  function openCredsDialog() {
    // write-only contract — we never preload existing values here (#for-bridge-secret-write-only)
    $('creds-key').value = '';
    $('creds-secret').value = '';
    [$('creds-key'), $('creds-secret')].forEach(updateHasValue);
    dlgCreds.showModal();
  }
  function wireCredsDialog() {
    $('dlg-creds-save').addEventListener('click', function () {
      var k = $('creds-key').value.trim();
      var s = $('creds-secret').value.trim();
      if (k && s) {
        bridge.setBybitCredentials(k, s);
        updateCredsIcon();
      }
      dlgCreds.close();
    });
    $('dlg-creds-clear').addEventListener('click', function () {
      bridge.clearBybitCredentials();
      updateCredsIcon();
      dlgCreds.close();
    });
    [$('creds-key'), $('creds-secret')].forEach(bindFieldLabelState);
  }

  function openIntervalDialog() {
    $('interval-value').value = String(bridge.getPollingIntervalSec());
    var cycles = bridge.getMaxLogCyclesDisplay();
    $('interval-cycles').value = cycles > 0 ? String(cycles) : '';
    [$('interval-value'), $('interval-cycles')].forEach(updateHasValue);
    setFieldError($('interval-value'), $('interval-value-error'), null);
    setFieldError($('interval-cycles'), $('interval-cycles-error'), null);
    dlgInterval.showModal();
  }
  function wireIntervalDialog() {
    $('dlg-interval-save').addEventListener('click', function () {
      var bounds = bridge.getPollingIntervalBounds();
      var val = parseInt($('interval-value').value, 10);
      if (isNaN(val) || val < bounds.min || val > bounds.max) {
        setFieldError(
          $('interval-value'), $('interval-value-error'),
          'Enter a number between ' + bounds.min + ' and ' + bounds.max,
        );
        return;
      }
      var cyclesRaw = $('interval-cycles').value.trim();
      var cyclesVal;
      if (cyclesRaw.length === 0) {
        cyclesVal = -1;
      } else {
        var n = parseInt(cyclesRaw, 10);
        if (isNaN(n) || n < 1 || n > 9999) {
          setFieldError(
            $('interval-cycles'), $('interval-cycles-error'),
            'Enter a number between 1 and 9999, or leave empty',
          );
          return;
        }
        cyclesVal = n;
      }
      setFieldError($('interval-value'), $('interval-value-error'), null);
      setFieldError($('interval-cycles'), $('interval-cycles-error'), null);
      bridge.setPollingIntervalSec(val);
      bridge.setMaxLogCyclesDisplay(cyclesVal);
      refreshIntervalLabel();
      refreshLog();
      dlgInterval.close();
    });
    [$('interval-value'), $('interval-cycles')].forEach(bindFieldLabelState);
  }

  // ---------- Settings (diagnostic) modal ----------
  /** One line per diagnostic action button (max 4); repeat press replaces that line only. */
  var diagLogSlots = { refresh: '', logcat: '', sign: '', force: '' };

  function renderDiagLog() {
    var pre = $('diag-log-view');
    var section = $('diag-log-section');
    var order = ['refresh', 'logcat', 'sign', 'force'];
    var lines = [];
    order.forEach(function (k) {
      if (diagLogSlots[k]) lines.push(diagLogSlots[k]);
    });
    pre.textContent = lines.join('\n');
    pre.scrollTop = pre.scrollHeight;
    if (section) section.hidden = lines.length === 0;
  }

  function setDiagLogSlot(slotKey, msg) {
    var ts = new Date().toISOString().substr(11, 12);
    diagLogSlots[slotKey] = ts + '  ' + msg;
    renderDiagLog();
  }

  function clearDiagLogSlots() {
    diagLogSlots.refresh = '';
    diagLogSlots.logcat = '';
    diagLogSlots.sign = '';
    diagLogSlots.force = '';
    renderDiagLog();
  }

  function refreshDiagnosticModal() {
    $('diag-shell-version').textContent = bridge.getShellVersion() || '—';
    $('diag-app-device-id').textContent = bridge.getAppDeviceId() || '—';
    $('diag-android-id').textContent = bridge.getDeviceId() || '—';
    $('diag-auth').textContent = bridge.isAuthenticated() ? 'yes' : 'no';
    $('diag-creds').textContent = bridge.hasBybitCredentials() ? 'stored' : 'missing';
    $('diag-service').textContent = bridge.isExecutorServiceRunning() ? 'running' : 'stopped';
  }
  function wireSettingsDialog() {
    gearBtn.addEventListener('click', function () {
      refreshDiagnosticModal();
      clearDiagLogSlots();
      dlgSettings.showModal();
    });
    $('diag-refresh').addEventListener('click', function () {
      refreshDiagnosticModal();
      setDiagLogSlot('refresh', 'state refreshed');
    });
    $('diag-logcat').addEventListener('click', function () {
      bridge.logToLogcat('INFO', 'MmbBundle', 'ping from bundle 26041724');
      setDiagLogSlot('logcat', 'logcat ping sent as INFO MmbBundle');
    });
    $('diag-sign').addEventListener('click', function () {
      try {
        var hex = bridge.signBybit('test-secret', 'probe-payload');
        setDiagLogSlot('sign', 'HMAC ok: ' + hex.substr(0, 16) + '…');
      } catch (e) {
        setDiagLogSlot('sign', 'HMAC fail: ' + (e && e.message));
      }
    });
    $('diag-force-cycle').addEventListener('click', function () {
      bridge.forceCycle();
      setDiagLogSlot('force', 'force cycle requested');
    });
    $('diag-clear').addEventListener('click', function () {
      clearDiagLogSlots();
    });
  }

  // ---------- Dashboard wiring ----------
  function wireDashboard() {
    runBtn.addEventListener('click', function () {
      state.runStopSelection = true;
      state.clearHighlight = false;
      stylizeRunStopButton();
      bridge.forceCycle();
    });
    stopBtn.addEventListener('click', function () {
      state.runStopSelection = false;
      state.clearHighlight = false;
      stylizeRunStopButton();
      bridge.stopExecutorService();
    });
    clearBtn.addEventListener('click', function () {
      bridge.clearEventLog();
      state.clearHighlight = true;
      stylizeRunStopButton();
      refreshLog();
    });
    logoutBtn.addEventListener('click', function () {
      bridge.clearSession();
      enterLogin();
    });
    intervalLabel.addEventListener('click', openIntervalDialog);
    credsBtn.addEventListener('click', openCredsDialog);
    gearBtn.addEventListener('click', function () { /* handled via wireSettingsDialog */ });
  }

  function wireTopbarDeviceViaLongPress() {
    // @causality #for-gear-long-press-device-id — gear short-press opens settings modal (diagnostic);
    // long-press (>=500ms) opens the Device ID dialog, matching ExecutorTopBar's device-id slot.
    var pressTimer = null;
    var longFired = false;
    gearBtn.addEventListener('touchstart', function () {
      longFired = false;
      pressTimer = setTimeout(function () {
        longFired = true;
        openDeviceDialog();
      }, 500);
    });
    var cancel = function () { if (pressTimer) { clearTimeout(pressTimer); pressTimer = null; } };
    gearBtn.addEventListener('touchend', cancel);
    gearBtn.addEventListener('touchcancel', cancel);
    gearBtn.addEventListener('touchmove', cancel);
    gearBtn.addEventListener('click', function (e) {
      if (longFired) { e.stopImmediatePropagation(); e.preventDefault(); longFired = false; }
    }, true);
  }

  // ---------- Login wiring ----------
  function wireLogin() {
    [jwtInput, jwtTa, keyField, secretField].forEach(function (el) {
      if (el) bindFieldLabelState(el);
    });
    [jwtInput, jwtTa, keyField, secretField].forEach(function (el) {
      if (el) el.addEventListener('input', updateConnectEnabled);
    });
    if (jwtInput && jwtTa) {
      jwtInput.addEventListener('focus', function () {
        if (!jwtTa.hidden) return;
        jwtTa.value = jwtInput.value;
        jwtInput.hidden = true;
        jwtTa.hidden = false;
        jwtTa.focus();
        var len = jwtTa.value.length;
        try { jwtTa.setSelectionRange(len, len); } catch (_e) {}
      });
      jwtTa.addEventListener('blur', function () {
        if (jwtTa.hidden) return;
        jwtInput.value = jwtTa.value;
        jwtTa.hidden = true;
        jwtInput.hidden = false;
        updateHasValue(jwtInput);
        updateHasValue(jwtTa);
      });
    }
    connectBtn.addEventListener('click', doConnect);
    wireLoginKeyboardFocus();
  }

  /**
   * When any login field is focused, collapse hero logo + footer so the field stack
   * can use vertical space while the soft keyboard is open (WebView/Android).
   * Connect / hint are not form fields — focusing them clears the compact layout.
   */
  function wireLoginKeyboardFocus() {
    if (!loginPanel) return;
    function isLoginField(el) {
      return el === jwtInput || el === jwtTa || el === keyField || el === secretField;
    }
    loginPanel.addEventListener('focusin', function (e) {
      if (isLoginField(e.target)) loginPanel.classList.add('login--field-focused');
    });
    loginPanel.addEventListener('focusout', function (e) {
      var next = e.relatedTarget;
      if (isLoginField(next)) return;
      loginPanel.classList.remove('login--field-focused');
    });
  }

  /**
   * Resolve light/dark for `<html data-theme>`. Explicit light/dark from store; legacy
   * `follow_system` follows `prefers-color-scheme` (WebView is driven from JS, not media alone).
   */
  function resolveEffectiveTheme() {
    var pref = bridge.getNightModePreference();
    if (pref === 'light') return 'light';
    if (pref === 'dark') return 'dark';
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }

  function applyHtmlTheme() {
    var t = resolveEffectiveTheme();
    document.documentElement.setAttribute('data-theme', t);
  }

  // Paint the Android system status-bar + navigation-bar using the same token the bundle
  // uses for its in-page header/footer chrome (`--surface-container`). Re-applied on theme
  // change so the OS chrome follows the bundle palette.
  function applySystemBarColors() {
    var root = getComputedStyle(document.documentElement);
    var token = root.getPropertyValue('--surface-container').trim() || '#252729';
    try {
      bridge.setSystemBarColors(token, token);
    } catch (_e) { /* older shell APK — method absent */ }
  }

  function syncThemeChrome(storedPref) {
    var p = (storedPref === 'light' || storedPref === 'dark') ? storedPref : resolveEffectiveTheme();
    var label = p === 'light' ? 'Color theme: light' : 'Color theme: dark';
    if (themeBtn) {
      themeBtn.dataset.themePref = p;
      themeBtn.setAttribute('aria-label', label);
    }
  }

  function cycleThemePreference() {
    var cur = bridge.getNightModePreference();
    var next;
    if (cur === 'light') next = 'dark';
    else if (cur === 'dark') next = 'light';
    else {
      next = resolveEffectiveTheme() === 'dark' ? 'light' : 'dark';
    }
    var res = bridge.setNightModePreference(next);
    if (!res || !res.ok) {
      try { bridge.toast('Install the latest app to change theme'); } catch (_e) {}
      return;
    }
    /* Activity recreates — DOM is replaced; no need to sync icons here. */
  }

  function wireThemeButtons() {
    if (themeBtn) themeBtn.addEventListener('click', cycleThemePreference);
  }

  // ---------- Boot ----------
  function boot() {
    applyHtmlTheme();
    wireLogin();
    wireDashboard();
    wireDialogCloseButtons();
    wireDialogBackdropClose();
    wireDeviceDialog();
    wireCredsDialog();
    wireIntervalDialog();
    wireSettingsDialog();
    wireTopbarDeviceViaLongPress();
    wireThemeButtons();

    syncThemeChrome(bridge.getNightModePreference());
    applySystemBarColors();
    if (window.matchMedia) {
      var mq = window.matchMedia('(prefers-color-scheme: dark)');
      var onScheme = function () {
        applyHtmlTheme();
        syncThemeChrome(bridge.getNightModePreference());
        applySystemBarColors();
      };
      if (typeof mq.addEventListener === 'function') {
        mq.addEventListener('change', onScheme);
      } else if (typeof mq.addListener === 'function') {
        mq.addListener(onScheme);
      }
    }

    if (bridge.isAuthenticated()) {
      enterDashboard();
    } else {
      enterLogin();
    }
    bridge.logToLogcat('INFO', 'MmbBundle', 'bundle 26041724 booted');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
