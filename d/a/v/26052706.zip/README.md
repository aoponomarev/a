---
id: readme-b58172
status: active
last_updated: "2026-05-24"

---
<!-- Важно: оставлять пустую строку перед "---" ! -->

Mirrored `fonts/` and `img/` from repo **a** `d/fonts/` and `d/img/` immediately before `vite build` (`is/scripts/android-shell/build-vue-bundle.js`). Gitignored `woff2` under `fonts/` are populated by that sync. Shell glyphs use `public/fonts` only — no `icons/` tree.
