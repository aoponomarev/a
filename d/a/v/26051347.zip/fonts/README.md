# Bundled fonts (WebView / `file://`)

| File | Source / license | Notes |
| --- | --- | --- |
| `roboto-condensed-*.woff2` | Fontdelivery / bundler subset | Log + `font/minimal` column |
| `MaterialIcons-Regular.woff2` | [Google Fonts / Material Icons](https://fonts.google.com/icons) (Apache 2.0) | Ligature icon font; ship in zip or ligatures render as plain text offline |

Segoe Fluent Icons is **not** redistributed here (Microsoft font redistribution restrictions). The TATC row uses **Fluent UI System Icons** SVG (MIT); canonical paths repo **a** `d/ico/fluent/` (**sync** before **`vite build`** per **`#for-mob-ui-app-icons-repo-a-d-ico`**).
